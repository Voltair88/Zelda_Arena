export * from './dude-inverse.sprite';
export * from './dude.sprite';
