module.exports = {
  semi: true,
  singleQuote: true,
  tabWidth: 2,
  bracketSpacing: true,
  trailingComma: 'none',
  printWidth: 120,
  endOfLine: 'auto'
};
